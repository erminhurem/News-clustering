from django.contrib import admin
from .models import Headlines

admin.site.register(Headlines)

