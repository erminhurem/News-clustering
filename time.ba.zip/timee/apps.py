from django.apps import AppConfig


class TimeeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'timee'
